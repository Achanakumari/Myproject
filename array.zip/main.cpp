#include <iostream>

using namespace std;
void printarray(int arr[] ,int size)
{
    for(int i=0; i<size; i++){
        cout<<arr[i]<< "" <<"\n";
    }
}

int main()
{
    int a[10]={6,4,8,7,9};
    int n=4;
    printarray(a,n);
    int asize = sizeof(a)/sizeof(int);

    cout<<"size of a "<<asize<<"\n";
    
    int b[6]= {7,8,4};
    n=6;
    printarray(b,n);

    return 0;
}
